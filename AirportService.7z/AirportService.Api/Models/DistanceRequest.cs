﻿namespace AirportService.Api.Models;

public record DistanceRequest(string OriginIata, string DestinationIata);