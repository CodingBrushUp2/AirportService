﻿public record DistanceResponse(double Distance, string Message);
