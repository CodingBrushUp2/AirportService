﻿namespace AirportService.Application.Interfaces
{
    public interface IAirportHttpClient
    {
    }
}