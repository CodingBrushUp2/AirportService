﻿namespace AirportService.Application.Interfaces;

public interface IAirportDataService
{
}