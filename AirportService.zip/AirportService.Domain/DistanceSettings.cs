﻿namespace AirportService.Api;

public class DistanceSettings
{
    public string DefaultUnit { get; set; }
    public string AirportApiUrl { get; set; }
}